def count_word(filename="story.txt", word_to_find=""):
    """Counts occurrences of a word in a text file."""

    try:
        with open(filename, "r") as f:
            contents = f.read().lower()
            word_count = contents.count(word_to_find.lower())
            return word_count
    except FileNotFoundError:
        return "Error: File not found."


word = input("Enter the word to search for: ")


count = count_word(word_to_find=word)
print(f"The word '{word}' appears {count} times in the file.")