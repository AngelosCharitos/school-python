import random

# Make a list with 20 random numbers (1-100)
numbers = [random.randint(1, 100) for _ in range(20)] 
print("List of random numbers:", numbers)

# Count the even numbers
even_count = 0
for number in numbers:
    if number % 2 == 0:  #Check if the number is even. If it is, the remainder is 0.
        even_count += 1

print("Number of even numbers:", even_count)