import random

# Make lists of letters and numbers.
lowercase = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
uppercase = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
symbols = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')']


def make_password():
    password = ""
    for i in range(10):  # make a password 10 letters long
        # Pick one of the lists at random.
        which_list = random.randint(1,4)
        if which_list == 1:
            password = password + random.choice(lowercase)
        elif which_list == 2:
            password = password + random.choice(uppercase)
        elif which_list == 3:
            password = password + random.choice(numbers)
        else:
            password = password + random.choice(symbols)
    return password


# Show the password.
print("Your password is:", make_password())