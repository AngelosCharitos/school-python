import os
import random

# File paths
users_file = "users.txt"
questions_file = "questions.txt"
score_file = "scores.txt"

# Function to check if user exists
def check_user_exists(username):
    if os.path.exists(users_file):
        with open(users_file, 'r') as file:
            users = file.readlines()
            for line in users:
                stored_user, _ = line.strip().split(',')
                if stored_user == username:
                    return True
    return False

# Function to register a new user
def register_user():
    username = input("Enter a username: ")
    if check_user_exists(username):
        print("User already exists!")
        return None
    password = input("Enter a password: ")
    with open(users_file, 'a') as file:
        file.write(f"{username},{password}\n")
    print("Registration successful!")
    return username

# Function to login a user
def login_user():
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    if os.path.exists(users_file):
        with open(users_file, 'r') as file:
            users = file.readlines()
            for line in users:
                stored_user, stored_password = line.strip().split(',')
                if stored_user == username and stored_password == password:
                    print("Login successful!")
                    return username
    print("Invalid username or password.")
    return None

# Function to read questions from a file
def read_questions():
    if not os.path.exists(questions_file):
        print("Questions file not found.")
        return []
    
    with open(questions_file, 'r') as file:
        lines = file.readlines()
        questions = []
        for line in lines:
            parts = line.strip().split(',')
            if len(parts) == 5:
                question = {
                    'question': parts[0],
                    'correct_answer': parts[1],
                    'options': parts[2:]
                }
                questions.append(question)
        return questions

# Function to select 5 random questions
def select_random_questions():
    questions = read_questions()
    if len(questions) < 5:
        print("Not enough questions available.")
        return []
    return random.sample(questions, 5)

# Function to ask a question
def ask_question(question):
    print(f"\n{question['question']}")
    options = question['options'] + [question['correct_answer']]
    random.shuffle(options)
    
    for idx, option in enumerate(options, 1):
        print(f"{idx}. {option}")
    
    answer = input("Select the correct answer (1-4): ")
    
    try:
        answer_idx = int(answer) - 1
        if options[answer_idx] == question['correct_answer']:
            return True
        else:
            return False
    except ValueError:
        print("Invalid input. Please enter a number between 1 and 4.")
        return False

# Function to update score
def update_score(username, score):
    if os.path.exists(score_file):
        with open(score_file, 'r') as file:
            scores = file.readlines()
        with open(score_file, 'w') as file:
            updated = False
            for line in scores:
                user, _ = line.strip().split(',')
                if user == username:
                    file.write(f"{username},{score}\n")
                    updated = True
                    break
            if not updated:
                file.write(f"{username},{score}\n")
    else:
        with open(score_file, 'w') as file:
            file.write(f"{username},{score}\n")
    print(f"Your score is {score}")

# Function to get current score
def get_current_score(username):
    if os.path.exists(score_file):
        with open(score_file, 'r') as file:
            scores = file.readlines()
            for line in scores:
                user, score = line.strip().split(',')
                if user == username:
                    return int(score)
    return 0

# Main game function
def play_quiz():
    print("Welcome to the quiz!")
    username = None
    
    while not username:
        choice = input("1. Login\n2. Register\nEnter choice: ")
        if choice == '1':
            username = login_user()
        elif choice == '2':
            username = register_user()
        else:
            print("Invalid choice, please try again.")

    score = get_current_score(username)
    print(f"Your current score: {score}")
    
    while True:
        questions = select_random_questions()
        if not questions:
            print("Sorry, there was a problem retrieving the questions.")
            return
        
        score = 0
        for question in questions:
            if ask_question(question):
                score += 1
        
        update_score(username, score)
        
        play_again = input("Do you want to play again? (y/n): ")
        if play_again.lower() != 'y':
            print("Thanks for playing!")
            break

if __name__ == "__main__":
    play_quiz()
