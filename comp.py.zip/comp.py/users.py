import csv

def check_credentials(username, pin):
    with open('users.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile) #Reads the file as a dictionary. Easier to use.
        for row in reader:
            if row['username'] == username and row['pin'] == pin:
                return row['name']  #Return the name if found
        return None  #Return nothing if not found


username = input("Enter username: ")
pin = input("Enter PIN: ")

name = check_credentials(username, pin)

if name:
    print(f"Welcome {name}")
else:
    print("Sorry, user not found")