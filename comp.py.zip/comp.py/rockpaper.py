import random
import datetime

def get_user_choice():
    while True:
        choice = input("Choose rock, paper, or scissors: ").lower()
        if choice in ["rock", "paper", "scissors"]:
            return choice
        else:
            print("Invalid choice. Please try again.")

def get_computer_choice():
    return random.choice(["rock", "paper", "scissors"])

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "tie"
    elif (user_choice == "rock" and computer_choice == "scissors") or \
         (user_choice == "paper" and computer_choice == "rock") or \
         (user_choice == "scissors" and computer_choice == "paper"):
        return "user"
    else:
        return "computer"

def play_game():
    username = input("Enter your username: ")
    user_score = 0
    computer_score = 0

    while user_score < 10 and computer_score < 10:
        user_choice = get_user_choice()
        computer_choice = get_computer_choice()
        print(f"You chose: {user_choice}, Computer chose: {computer_choice}")

        winner = determine_winner(user_choice, computer_choice)
        if winner == "user":
            user_score += 1
            print("You win!")
        elif winner == "computer":
            computer_score += 1
            print("Computer wins!")
        else:
            print("It's a tie!")

        print(f"Score: You - {user_score}, Computer - {computer_score}")

    save_score(username, user_score, computer_score)
    print("Game Over!")
    if user_score >= 10:
        print(f"{username} wins the match!")
    else:
        print("Computer wins the match!")


def save_score(username, user_score, computer_score):
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    with open("scores.txt", "a") as f:
        f.write(f"{username},{timestamp},{user_score},{computer_score}\n")

play_game()
