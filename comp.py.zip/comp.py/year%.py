year = int(input("Enter a year: "))

if year % 4 != 0:  # Case 1: Not divisible by 4
    print(f"{year} is not a leap year.")
elif year % 100 == 0:  # Case 3 & 4: Divisible by 4 and 100
    if year % 400 == 0:  # Case 4: Divisible by 400
        print(f"{year} is a leap year.")
    else:  # Case 3: Not divisible by 400
        print(f"{year} is not a leap year.")
else:  # Case 2: Divisible by 4 but not by 100
    print(f"{year} is a leap year.")
